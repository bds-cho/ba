var mysql = require('mysql');

var connection = mysql.createConnection({
    host: 'rds.cja2s0gm0289.eu-central-1.rds.amazonaws.com',
    user: 'admin',
    password: 'adminadmin',
    database: 'rds-mysql-db'
});

connection.connect();

exports.handler = async (event) => {
    const query = "SELECT * FROM users WHERE users.id = "+(randomIntFromInterval(1,1000))+";";
    
    return new Promise((resolve, reject) => {
    
        const start = Date.now();
        connection.query(query, (err, res) => {
            const end = Date.now();
            //connection.end();
            if (err) {
                reject({
                    statusCode: 500,
                });
            } else {
                const resultString = JSON.stringify(res);
                resolve({
                    statusCode: 200,
                    body: JSON.stringify({
                        start: start,
                        result: resultString,
                        end: end
                    }),
                });
            } 
        }); 
    });   
};

function randomIntFromInterval(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}
