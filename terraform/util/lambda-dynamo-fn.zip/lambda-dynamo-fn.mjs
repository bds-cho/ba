import { DynamoDBClient, GetItemCommand } from "@aws-sdk/client-dynamodb";
import { marshall } from "@aws-sdk/util-dynamodb";

const client = new DynamoDBClient({"region": "eu-central-1"});

export const handler = async (event) => {

  const params = {
      TableName: "dynamo",
      Key: marshall({
        id: 5
      })
  };
  
  try {
      const start = Date.now();
      const result = await client.send(new GetItemCommand(params));
      const end = Date.now();
      return {
          statusCode: 200,
          body: JSON.stringify({
            start: start,
            result: result.Item,
            end: end
          }),
      };
  } catch (error) {
      console.error("Query failed:", error);
      return {
          statusCode: 500,
          body: JSON.stringify({
            error: 'Could not retrieve data',
          }),
      };
  }
  
};

