const mysql = require('mysql2/promise');  // Use mysql2 with promise support

const connectionConfig = {
    host: 'rds.cja2s0gm0289.eu-central-1.rds.amazonaws.com',
    user: 'admin',
    password: 'adminadmin',
    database: 'rds-mysql-db'
};

exports.handler = async (event) => {
    let connection;
    try {
        connection = await mysql.createConnection(connectionConfig);
        
        const query = "SELECT * FROM users WHERE users.id = 500;";
        
        const start = Date.now();
        const [rows,columns] = await connection.execute(query);
        const end = Date.now();
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                start: start,
                result: rows,
                end: end
            }),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({
                error: 'Could not retrieve data',
                details: error.message
            }),
        };
    } finally {
        if (connection) {
            await connection.end();  // Ensure the connection is closed
        }
    }
};


