import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

const s3Client = new S3Client({ region: 'eu-central-1' });

export const handler = async (event) => {
  const command = new GetObjectCommand({ Bucket: 'tf-ba-bucket', Key: 's3-object.txt' });
  
  try {
    const start = Date.now();
    const result = await s3Client.send(command);
    const end = Date.now();
    const str = await result.Body.transformToString();
    return {
      statusCode: 200,
      body: JSON.stringify({
        start: start,
        result: str,
        end: end
      }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify("ERROR500")
    }
  }
  
};
